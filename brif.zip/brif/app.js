document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('briefForm');
    const btn = document.querySelector('.submit-btn');
    const notification = document.getElementById('notification');
    
    btn.addEventListener('click', async function(e) {
        e.preventDefault();
        
        if(form.checkValidity()) {
            showNotification('Создаем PDF...');
            
            try {
                // Создаем PDF
                const pdfBlob = await generatePDF();
                
                // Отправляем в Telegram
                await sendToTelegram(pdfBlob);
                
                showNotification('Бриф успешно отправлен!');
                form.reset();
            } catch (error) {
                console.error(error);
                showNotification('Ошибка отправки: ' + error.message, true);
            } finally {
                setTimeout(() => {
                    notification.style.display = 'none';
                }, 3000);
            }
        } else {
            showNotification('Заполните все обязательные поля', true);
        }
    });
    
    async function generatePDF() {
        const opt = {
            margin: 10,
            filename: CONFIG.PDF_FILENAME,
            image: { type: 'jpeg', quality: 0.98 },
            html2canvas: { 
                scale: 2,
                logging: true,
                useCORS: true,
                letterRendering: true
            },
            jsPDF: { 
                unit: 'mm', 
                format: 'a4', 
                orientation: 'portrait' 
            }
        };
        
        const worker = html2pdf().set(opt).from(form);
        const pdf = await worker.outputPdf('blob');
        return pdf;
    }
    
    async function sendToTelegram(pdfBlob) {
        const formData = new FormData();
        formData.append('chat_id', CONFIG.TELEGRAM_CHAT_ID);
        formData.append('document', pdfBlob, CONFIG.PDF_FILENAME);
        formData.append('caption', CONFIG.CAPTION);
        
        const response = await fetch(`https://api.telegram.org/bot${CONFIG.TELEGRAM_BOT_TOKEN}/sendDocument`, {
            method: 'POST',
            body: formData
        });
        
        if (!response.ok) {
            throw new Error('Ошибка Telegram API');
        }
        
        return await response.json();
    }
    
    function showNotification(message, isError = false) {
        notification.textContent = message;
        notification.style.display = 'block';
        notification.style.backgroundColor = isError ? '#FF4D4D' : '#333';
    }
});