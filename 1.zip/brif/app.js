document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('briefForm');
    const btn = document.querySelector('.submit-btn');
    const notification = document.getElementById('notification');
    
    btn.addEventListener('click', async function(e) {
        e.preventDefault();
        
        if(form.checkValidity()) {
            showNotification('Отправляем данные...');
            
            try {
                // Формируем текстовое сообщение из данных формы
                const message = formatFormData(form);
                
                // Отправляем в Telegram
                await sendToTelegram(message);
                
                showNotification('Данные успешно отправлены!');
                form.reset();
            } catch (error) {
                console.error(error);
                showNotification('Ошибка отправки: ' + error.message, true);
            } finally {
                setTimeout(() => {
                    notification.style.display = 'none';
                }, 3000);
            }
        } else {
            showNotification('Заполните все обязательные поля', true);
        }
    });
    
    function formatFormData(form) {
        const formData = new FormData(form);
        let message = '📋 *Новый бриф с сайта*\n\n';
        
        // Добавляем контактные данные
        message += `*👤 Контактные данные:*\n`;
        message += `• Имя: ${formData.get('client-name')}\n`;
        if(formData.get('company-name')) {
            message += `• Компания: ${formData.get('company-name')}\n`;
        }
        message += `• Телефон: ${formData.get('phone')}\n`;
        message += `• WhatsApp: ${formData.get('whatsapp')}\n\n`;
        
        // Добавляем информацию о проекте
        message += `*🖥 О проекте:*\n`;
        message += `• Тип сайта: ${formData.get('project-type')}\n`;
        message += `• Цель: ${formData.get('project-goal')}\n`;
        if(formData.get('target-audience')) {
            message += `• ЦА: ${formData.get('target-audience')}\n`;
        }
        message += `\n`;
        
        // Добавляем дизайн
        message += `*🎨 Дизайн:*\n`;
        if(formData.get('references')) {
            message += `• Примеры: ${formData.get('references')}\n`;
        }
        if(formData.get('colors')) {
            message += `• Цвета: ${formData.get('colors')}\n`;
        }
        message += `\n`;
        
        // Добавляем функционал
        message += `*⚙ Функционал:*\n`;
        if(formData.get('features')) {
            message += `• Функции: ${formData.get('features')}\n`;
        }
        if(formData.get('integration')) {
            message += `• Интеграции: ${formData.get('integration')}\n`;
        }
        message += `\n`;
        
        // Добавляем сроки и бюджет
        message += `*💰 Сроки и бюджет:*\n`;
        if(formData.get('deadline')) {
            message += `• Сроки: ${formData.get('deadline')}\n`;
        }
        if(formData.get('budget')) {
            message += `• Бюджет: ${formData.get('budget')}\n`;
        }
        message += `\n`;
        
        // Добавляем комментарии
        if(formData.get('comments')) {
            message += `*📝 Комментарии:*\n${formData.get('comments')}\n`;
        }
        
        return message;
    }
    
    async function sendToTelegram(message) {
        // Кодируем сообщение для URL
        const encodedMessage = encodeURIComponent(message);
        
        const response = await fetch(
            `https://api.telegram.org/bot${CONFIG.TELEGRAM_BOT_TOKEN}/sendMessage?chat_id=${CONFIG.TELEGRAM_CHAT_ID}&text=${encodedMessage}&parse_mode=Markdown`
        );
        
        if (!response.ok) {
            throw new Error('Ошибка Telegram API');
        }
        
        return await response.json();
    }
    
    function showNotification(message, isError = false) {
        notification.textContent = message;
        notification.style.display = 'block';
        notification.style.backgroundColor = isError ? '#FF4D4D' : '#333';
    }
});