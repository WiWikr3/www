// Конфигурация Telegram бота
const CONFIG = {
    TELEGRAM_BOT_TOKEN: '7752700177:AAFsRda06W1bujhKhD8xmHunBDTCldHb-AI',
    TELEGRAM_CHAT_ID: '8108428506',
    PDF_FILENAME: 'Бриф_ProfitWeb.pdf',
    CAPTION: 'Новый заполненный бриф с сайта'
};